package bg.softuni.Fundamentals.Exercise.L21ObjectsAndClasses.More.T02RawData;

public class Engine {
    private int speed, power;

    public int getPower() {
        return power;
    }

    public Engine(int speed, int power) {
        this.speed = speed;
        this.power = power;
    }
}
